close all;
clear all;


vis_delay = 0.5;
desired_state = [0, 0, 0, 0, 0, 0, 0;
                 0, 0, 2, 2, 2, 0, 0;
                 0, 2, 0, 2, 0, 2, 0;
                 0, 2, 2, 2, 2, 2, 0;
                 0, 2, 0, 2, 0, 2, 0;
                 0, 0, 2, 2, 2, 0, 0;
                 0, 0, 0, 0, 0, 0, 0];

state = zeros(7);

% desired_state = [0 2 0;
%                  2 0 2;
%                  0 2 0];
% 
% state = zeros(3);

[rows, cols] = size(state);
% initialize figure
figure;
visualize_state(state)
pause(vis_delay)

%define parameters
gamma = 0.75; 
theta = 1e-2;

[optimal_policy, optimal_value] = value_iteration(state, rows,cols, gamma, theta, desired_state); %added theta

%% implement value iteration
writerObj = VideoWriter('test7.avi'); %// initialize the VideoWriter object
open(writerObj) ;
c = 1;
while ~isequal(state, desired_state)
  for i = 1:rows
    for j = 1:cols
      if state(i,j) ~= desired_state(i,j)
          fill_lvl = state(i,j)+1;
          action = optimal_policy{i,j}(fill_lvl);
          if action == "add"
              state = add_action(state, [i,j]);
          else
              state = sub_action(state, [i,j]); %subtractive action
          end
          visualize_state(state)
          pause(vis_delay)
          F(c:c+20) = getframe ;           %// Capture the frame
          c = c+20;
      end
    end
  end
end
writeVideo(writerObj,F)

close(writerObj);












