function [V_s] = lookahead(s, i, j, a, gamma, V, desired_s)
T = state_transition(s,a);
% state_prob_length = size(T,3);
R = reward_assignment(s,desired_s);
%part of reward - streak bonus (cant't do w value iteration)
% if a == past_a
%     gamma = 0.9;
% end
V_uniq = zeros(1,3);
state_prob = zeros(1,3);
for k=1:3
    sp = T{i,j};
    state_prob(k) = sp{2};
    fill_lvl = sp{1}(i,j) + 1;%fill at the specific cell
    V_uniq(k) = V{i,j}(fill_lvl);
end
V_s = sum(R,"all") + gamma*sum(state_prob.*V_uniq);
end