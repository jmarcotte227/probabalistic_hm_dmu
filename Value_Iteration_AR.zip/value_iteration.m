% Value iteration function
function [policy, V] = value_iteration(state, rows,cols, gamma, theta, desired_s)
    fill_q = 3;
    V = repmat({zeros(1,3)},rows,cols); % Initialize value function. value for s(i,j) = 0,1,2?
    policy = repmat({["add", "add", "add"]},rows,cols); % Initialize policy
    actions = ["add","subtract"];
    % TODO: Implement the value iteration algorithm
    Q = zeros(rows,cols,fill_q, 2); %Initialize state-action value function
    A = zeros(rows,cols,fill_q, 2); %Initialize advantage function
    if abs(max(A-Q)) < theta
    for i=1:rows
        for j=1:cols
            for fl = 1:fill_q
                for k = 1:2 %for each action,
                    a = actions(k); 
                    %get reward for that action, using new V
                    [V_s] = lookahead(state, i, j, a, gamma, V, desired_s);
                    Q(i,j,fl,k) = V_s; %update Q
                end
            
                %update policy
                [Q_max, argmax] = max(Q(i,j,fl,:));
                actions(argmax)
                policy{i,j}(fl) = char(actions(argmax));
                %update V
                V{i,j}(fl) = Q_max;
               
                %update advantage function
                A(i,j,fl,argmax) = Q(i,j,fl,argmax) - V{i,j}(fl); 
            end
        end
    end

    else
        return
    end

end